function loco() {
  gsap.registerPlugin(ScrollTrigger);

  // Using Locomotive Scroll from Locomotive https://github.com/locomotivemtl/locomotive-scroll

  const locoScroll = new LocomotiveScroll({
    el: document.querySelector("#main"),
    smooth: true,
  });
  // each time Locomotive Scroll updates, tell ScrollTrigger to update too (sync positioning)
  locoScroll.on("scroll", ScrollTrigger.update);

  // tell ScrollTrigger to use these proxy methods for the ".smooth-scroll" element since Locomotive Scroll is hijacking things
  ScrollTrigger.scrollerProxy("#main", {
    scrollTop(value) {
      return arguments.length
        ? locoScroll.scrollTo(value, 0, 0)
        : locoScroll.scroll.instance.scroll.y;
    }, // we don't have to define a scrollLeft because we're only scrolling vertically.
    getBoundingClientRect() {
      return {
        top: 0,
        left: 0,
        width: window.innerWidth,
        height: window.innerHeight,
      };
    },
    // LocomotiveScroll handles things completely differently on mobile devices - it doesn't even transform the container at all! So to get the correct behavior and avoid jitters, we should pin things with position: fixed on mobile. We sense it by checking to see if there's a transform applied to the container (the LocomotiveScroll-controlled element).
    pinType: document.querySelector("#main").style.transform
      ? "transform"
      : "fixed",
  });
}

loco();

document.querySelectorAll(".h6_line").forEach(function (elm) {
  var line = elm.children[1];
  elm.addEventListener("mouseenter", function () {
    gsap.to(line, {
      width: "100%",
      opacity: 1,
      ease: Expo.easeInout,
      duration: 0.2,
    });
  });
});

document.querySelectorAll(".h6_line").forEach(function (elm) {
  var line = elm.children[1];
  elm.addEventListener("mouseleave", function () {
    gsap.to(line, {
      width: "0%",
      left: "100%",
      opacity: 0,
      ease: Expo.easeInout,
      duration: 1,

      onComplete: function () {
        line.style.left = 0;
      },
    });
  });
});

function m_nav() {
  var i = 0;
  var hoveri = document.querySelector(".m_nav .link i");

  hoveri.addEventListener("click", function () {
    if (i === 0) {
      hoveri.classList = "ri-arrow-up-s-line";
      gsap.to(".m_nav .ao a", {
        opacity: 1,
        stagger: 0.1,
        ease: Expo.easeInout,
        duration: 1,
      });
      i = 1;
    } else {
      gsap.to(".m_nav .ao a", {
        opacity: 0,
        stagger: 0.1,
        ease: Expo.easeInout,
        duration: 1,
      });
      hoveri.classList = "ri-arrow-down-s-line";
      i = 0;
    }
  });

  var m = 0;
  var menu = document.querySelector("#menu");
  menu.addEventListener("click", function () {
    if (m === 0) {
      gsap.to(".m_nav", {
        x: 0,
        ease: Expo.easeInout,
      });
      m = 1;
    } else {
      gsap.to(".m_nav", {
        x: -850,
        ease: Expo.easeInout,
      });
      m = 0;
    }
  });

  document.querySelector("#closeM").addEventListener("click", function () {
    gsap.to(".m_nav", {
      x: -850,
      ease: Expo.easeInout,
    });
  });
}
m_nav();

function main_loader() {
  var tl = gsap.timeline();
  tl.to("#fs .pink", {
    top: "50%",
    ease: Expo.easeInout,
    duration: 1,
  })
    .to("#fs img", {
      y: 0,
      ease: Expo.easeInout,
      duration: 1,
    })
    .to("#fs .img", {
      overflow: "initial",
    })
    .to("#fs img", {
      scale: 5,
      ease: Expo.easeInout,
      duration: 2,
      // opacity:0
    })
    .to("#fs img", {
      delay: -1,
      opacity: 0,
      duration: 0.1,
    })
    .to("#fs", {
      delay: -0.5,
      height: "0vh",
      borderBottomLeftRadius: "100%",
      borderBottomRightRadius: "100%",
      display: "none",
      ease: Expo.easeInout,
      duration: 1,
    })
    .to(".links a ", {
      delay: -0.2,
      y: 0,
      ease: Expo.easeInout,
      duration: 1,
    })
    .to("#nav .icon", {
      delay: -1.2,
      y: 0,
      ease: Expo.easeInout,
      duration: 1,
    })

    .to(".cart", {
      delay: -1,
      y: 0,
      ease: Expo.easeInout,
      duration: 1,
    })
    .to(".pg1 h1", {
      delay: -1,
      y: 0,
      ease: Expo.easeInout,
      duration: 1,
    })
    .to(".main_text small", {
      opacity: 1,
      delay: -0.5,
      ease: Expo.easeInout,
      duration: 0.5,
    })
    .to(".main_text .buttons ", {
      delay: -0.5,
      opacity: 1,
      ease: Expo.easeInout,
      duration: 0.5,
    });
}

main_loader();



gsap.to("#ocard1", {
    scrollTrigger: {
      trigger: ".pg2",
      scroller: "#main",
      start: "top 70%",
    //   end: "top 60%",
    },
    x:0,
    ease: Expo.easeInout,
    duration:1,
  })

  gsap.to("#ocard3", {
    scrollTrigger: {
      trigger: ".pg2",
      scroller: "#main",
      start: "top 70%",
    //   end: "top 60%",
    },
    x:0,
    ease: Expo.easeInout,
    duration:1,
  })
  gsap.to("#ocard2", {
    scrollTrigger: {
      trigger: ".pg2",
      scroller: "#main",
      start: "top 70%",
    },
    opacity:1,
    ease: Expo.easeInout,
    duration:1,
  })

  gsap.to(".pg2_btm .left_img", {
    scrollTrigger: {
      trigger: ".pg2",
      scroller: "#main",
      start: "top 10%",
    },
    x:0,
    ease: Expo.easeInout,
    duration:1,
  })

  gsap.to(".pg2 h1", {
    scrollTrigger: {
      trigger: ".pg2",
      scroller: "#main",
      start: "top 10%",
    },
    opacity:1,
    ease: Expo.easeInout,
    duration:1,
  })

  gsap.to(".pg2 p", {
    scrollTrigger: {
      trigger: ".pg2",
      scroller: "#main",
      start: "top 10%",
    },
    y:0,
    ease: Expo.easeInout,
    duration:1,
  })

  gsap.to(".pg2 .btns", {
    scrollTrigger: {
      trigger: ".pg2",
      scroller: "#main",
      start: "top 10%",
    },
    opacity:1,
    ease: Expo.easeInout,
    duration:1,
  })



  
  gsap.to(".pg2 .pg2_opt", {
    scrollTrigger: {
      trigger: ".pg2",
      scroller: "#main",
      start: "top 5%",
    },
    opacity:1,
    ease: Expo.easeInout,
    duration:1,
  })


  gsap.to(".pg3 .left_txt", {
    scrollTrigger: {
      trigger: ".pg3",
      scroller: "#main",
      start: "top 30%",
    },
    opacity:1,
    ease: Expo.easeInout,
    duration:1,
  })


  gsap.to(".pg3 .opt", {
    scrollTrigger: {
      trigger: ".pg3",
      scroller: "#main",
      start: "top 30%",
    },
    opacity:1,
    ease: Expo.easeInout,
    duration:1,
    stagger:.08,
  })



  gsap.to(".overlay-top h1", {
    scrollTrigger: {
      trigger: ".pg4",
      scroller: "#main",
      start: "top 50%",
    },
    y:-21,
    ease: Expo.easeInout,
    duration:1,
    stagger:.08,
  })

  gsap.to(".c_card", {
    scrollTrigger: {
      trigger: ".pg4",
      scroller: "#main",
      start: "top 5%",
    },
    opacity:1,
    ease: Expo.easeInout,
    stagger:.08,
  })

  
  gsap.to(".pg5 h1", {
    scrollTrigger: {
      trigger: ".pg5",
      scroller: "#main",
      start: "top 55%",
    },
    opacity:1,
    ease: Expo.easeInout,
  })

    
  gsap.to(".pg5>.gm", {
    scrollTrigger: {
      trigger: ".pg5",
      scroller: "#main",
      start: "top 55%",
    },
    opacity:1,
    ease: Expo.easeInout,
  })


  gsap.to(".pg6-top h1", {
    scrollTrigger: {
      trigger: ".pg6",
      scroller: "#main",
      start: "top 55%",
    },
    y:0,
    duration:1,
    ease: Expo.easeInout,
  })

  gsap.to(".pg6 .swipe", {
    scrollTrigger: {
      trigger: ".pg6",
      scroller: "#main",
      start: "top 80%",
    },
    opacity:1,
    duration:1,
    ease: Expo.easeInout,
  })

  gsap.to(".pg7_top", {
    scrollTrigger: {
      trigger: ".pg7",
      scroller: "#main",
      start: "top 40%",
    },
    opacity:1,
    duration:1,
    ease: Expo.easeInout,
  })


  gsap.to(".pg7_btm .left", {
    scrollTrigger: {
      trigger: ".pg7",
      scroller: "#main",
      start: "top 40%",
    },
    opacity:1,
    stagger:.2,
    ease: Expo.easeInout,
  })

  gsap.to(".footer .ftr", {
    scrollTrigger: {
      trigger: ".pg7",
      scroller: "#main",
      start: "top 30%",
    },
    opacity:1,
    ease: Expo.easeInout,
  })



 